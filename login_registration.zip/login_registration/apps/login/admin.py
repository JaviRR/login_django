from django.contrib import admin
from apps.login.models import User

admin.site.register(User)